import React from 'react'

export default function Addagent() {
  return (
    <div>Addagent</div>
  )
}
